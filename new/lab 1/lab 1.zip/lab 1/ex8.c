#include<stdio.h>
int main()
{
    int x,y,remainder;
    scanf("%d %d",&x,&y);
    remainder=x%y;
    printf("%d",remainder);
    return 0;
}
