#include<stdio.h>
int main()
{int x,y,sum;
scanf("%d %d",&x,&y);
sum=x+y;
if(sum>5)
printf("well done",sum);
else
printf("try again later",sum);
return 0;}
