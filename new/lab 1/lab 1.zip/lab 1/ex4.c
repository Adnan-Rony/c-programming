#include<stdio.h>
int main()
{
    int x=5,y=8,z=3,sum;
    sum=x+y+z;
    printf("%d+%d+%d=%d",x,y,z,sum);
    return 0;
}
