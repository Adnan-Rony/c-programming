#include<stdio.h>
int main()
{
    int x=5,y=5,sum;
    sum=x+y;
    printf("%d",sum);
    return 0;
}
