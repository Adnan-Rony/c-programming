#include<stdio.h>
int main()
{
    int x=5,y=3,sum,subtract,multiply;
    sum=x+y;
    subtract=sum-(sum/2);
    multiply=subtract*3;
    printf("%d\n",multiply);
    return 0;
}
