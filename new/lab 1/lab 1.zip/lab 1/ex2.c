#include<stdio.h>
int main()
{
    printf("1.pizza\n 2.baked pasta\n 3.burger");
    return 0;
}
