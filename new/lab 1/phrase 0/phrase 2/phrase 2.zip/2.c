#include<stdio.h>
int main()
{
    int n;
    printf("Can you give some apple,please?\n");
    scanf("%d",&n);
    if(n>5)
    {
        printf("Thank you very much");
    }
    return 0;
}
