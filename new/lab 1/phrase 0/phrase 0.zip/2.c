
#include<stdio.h>
int main(){
printf("MD AL ADNAN RONY\t 221-15-5155");
return 0;
}

