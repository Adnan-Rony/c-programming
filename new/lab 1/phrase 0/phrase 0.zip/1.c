
#include<stdio.h>
int main(){
printf("MD AL ADNAN RONY\n");
return 0;
}
