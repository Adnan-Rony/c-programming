
#include<stdio.h>
int main(){
    int x,y,sum;
    scanf("%d%d",&x,&y);
    sum=x+y;
    printf("%d",sum);

return 0;
}

